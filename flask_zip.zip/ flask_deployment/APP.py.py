from flask import Flask, render_template, request
import pickle
import xgboost as xgb
import pandas as pd

model = pickle.load(open('boosting_xg112.pk', 'rb'))
app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html", insurance_cost=None)


@app.route('/predict', methods=['POST'])
def predict_insurance_cost():
    age = request.form.get('Age')
    sex = request.form.get('Sex')
    bmi = request.form.get('BMI')
    children = request.form.get('Children')
    smoker = request.form.get('Smoker')
    region = request.form.get('Region')

    insurance_cost = calculate_insurance_cost(age, sex, bmi, children, smoker, region)
    return render_template("index.html", insurance_cost=insurance_cost)


def calculate_insurance_cost(age, sex, bmi, children, smoker, region):
    # Convert sex, smoker, and region to numerical values
    sex_l = 1 if sex == "Male" else 0
    smoker_l = 1 if smoker == "Yes" else 0

    if region == "Southwest":
        region_l = 3
    elif region == "Southeast":
        region_l = 1
    elif region == "Northeast":
        region_l = 0
    elif region == "Northwest":
        region_l = 2

    # Create a DataFrame with input data
    input_data = {
        'age': [int(age)],
        'bmi': [float(bmi)],
        'children': [int(children)],
        'sex_l': [sex_l],
        'smoker_l': [smoker_l],
        'region_l': [region_l]
    }
    input_df = pd.DataFrame(input_data)

    # Predict the insurance cost
    dtest = xgb.DMatrix(input_df)
    insurance_cost = model.predict(dtest)[0]

    return round(insurance_cost, 2)


if __name__ == "__main__":
    app.run()
